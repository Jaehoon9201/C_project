/**    data_com.c .
*
*   @brief CAN-based data communication function
*   @author  Jaehoon Shim and Jung-Ik Ha
*   @date    2022.12 - 2023.11
*   @version 1.0.0
*   @section INFO
*   - This project is supported by LG Innotek coporation.
*
*/

/*********************************************************************************************************************/
/*-----------------------------------------------------Includes------------------------------------------------------*/
/*********************************************************************************************************************/
#include "data_com.h"
#include "utility.h"
/*********************************************************************************************************************/
/*-------------------------------------------------Variables definition --------------------------------------------------*/
/*********************************************************************************************************************/
McmcanType                  g_mcmcan;                       /* Global MCMCAN configuration and control structure    */

IFX_CONST IfxCan_Can_Pins Can00_pins = {
    &IfxCan_TXD00_P20_8_OUT, IfxPort_OutputMode_pushPull,   // CAN00_TX
    &IfxCan_RXD00B_P20_7_IN, IfxPort_InputMode_pullUp,      // CAN00_RX
    IfxPort_PadDriver_cmosAutomotiveSpeed4
};


int tx_trigger = 0;
int splitter1 = 0;
int splitter2 = 0;
int splitter3 = 0;
int startidx = 0;
float sinval[3600];
/*********************************************************************************************************************/
/*---------------------------------------------Function Implementations----------------------------------------------*/
/*********************************************************************************************************************/
/*
 * Macro to define Interrupt Service Routine.
 * This macro:
 * - defines linker section as .intvec_tc<vector number>_<interrupt priority>.
 * - defines compiler specific attribute for the interrupt functions.
 * - defines the Interrupt service routine as ISR function.
 *
 * IFX_INTERRUPT(isr, vectabNum, priority)
 *  - isr: Name of the ISR function.
 *  - vectabNum: Vector table number.
 *  - priority: Interrupt priority. Refer Usage of Interrupt Macro for more details.
 *
 *  from) aurix example github
 */
IFX_INTERRUPT(canIsrTxHandler, 0, ISR_PRIORITY_CAN_TX);

int cnttx = 0;
void canIsrTxHandler(void)
{
    cnttx++;
    /* Clear the "Transmission Completed" interrupt flag */
    IfxCan_Node_clearInterruptFlag(g_mcmcan.canSrcNode.node, IfxCan_Interrupt_transmissionCompleted);
    if (cnttx % 2 ==0){
        IfxPort_togglePin(g_led1.port, g_led1.pinIndex);
        if (cnttx> 10000){cnttx = 0;}
    }
}

/**
 *
 * @brief Function to initialize MCMCAN module and nodes related for this application use case
 * @param null
 * @return null
 *
 */
void initdatacan(void)
{

    /* ==========================================================================================
     * CAN module configuration and initialization:
     * ==========================================================================================
     *  - load default CAN module configuration into configuration structure
     *  - initialize CAN module with the default configuration
     * ==========================================================================================
     */
    IfxCan_Can_initModuleConfig(&g_mcmcan.canConfig, &MODULE_CAN0);
    IfxCan_Can_initModule(&g_mcmcan.canModule, &g_mcmcan.canConfig);

    /* ==========================================================================================
     * Destination CAN node configuration and initialization:
     * ==========================================================================================
     *  - needless to consider
     * ==========================================================================================
     */
    IfxCan_Can_initNodeConfig(&g_mcmcan.canNodeConfig, &g_mcmcan.canModule);
    //g_mcmcan.canNodeConfig.busLoopbackEnabled = TRUE;
    g_mcmcan.canNodeConfig.nodeId = IfxCan_NodeId_1;
    g_mcmcan.canNodeConfig.frame.type = IfxCan_FrameType_receive;
    g_mcmcan.canNodeConfig.interruptConfig.messageStoredToDedicatedRxBufferEnabled = TRUE;
    g_mcmcan.canNodeConfig.interruptConfig.reint.priority = ISR_PRIORITY_CAN_RX;
    g_mcmcan.canNodeConfig.interruptConfig.reint.interruptLine = IfxCan_InterruptLine_1;
    g_mcmcan.canNodeConfig.interruptConfig.reint.typeOfService = IfxSrc_Tos_cpu0;
    IfxCan_Can_initNode(&g_mcmcan.canDstNode, &g_mcmcan.canNodeConfig);

    /* ==========================================================================================
     * ■ Source CAN node configuration and initialization:
     * ==========================================================================================
     *  - ■ This part(pin and node configuration) must be adjust considering LGIT's setup of H/W and S/W.
     *  - ■ SNU tested with 'Can00_pins'.
     * ==========================================================================================
     */
    IfxCan_Can_initNodeConfig(&g_mcmcan.canNodeConfig, &g_mcmcan.canModule);
    //g_mcmcan.canNodeConfig.busLoopbackEnabled = TRUE;   // --> LBM Set together
    g_mcmcan.canNodeConfig.nodeId = IfxCan_NodeId_0;
    g_mcmcan.canNodeConfig.frame.type = IfxCan_FrameType_transmit;
    g_mcmcan.canNodeConfig.interruptConfig.transmissionCompletedEnabled = TRUE;
    g_mcmcan.canNodeConfig.interruptConfig.traco.priority = ISR_PRIORITY_CAN_TX;
    g_mcmcan.canNodeConfig.interruptConfig.traco.interruptLine = IfxCan_InterruptLine_0;
    g_mcmcan.canNodeConfig.interruptConfig.traco.typeOfService = IfxSrc_Tos_cpu0;

    g_mcmcan.canNodeConfig.pins = &Can00_pins;
    IfxCan_Can_initNode(&g_mcmcan.canSrcNode, &g_mcmcan.canNodeConfig);


}


/**
 *
 * @brief Transmitting TX messages
 * @param null
 * @return null
 *
 */

void transmitCanMessage(struct TransData *TD)
{
    if (tx_trigger==1){
        if(startidx < 90){
            switch(splitter3){
                case 0 :
                    //-------------------------------------------------------------------------------
                    //                              CAN_MESSAGE_ID 1
                    //-------------------------------------------------------------------------------
                    /* Initialization of the TX message with the default configuration */
                    IfxCan_Can_initMessage(&g_mcmcan.txMsg);
                    /* Define the content of the data to be transmitted */
                    for (int didx= startidx; didx< startidx+2; didx++){ g_mcmcan.txData[didx-startidx] = TD->u32_data1[didx]; }
                    /* Set the message ID that is used during the receive acceptance phase */
                    g_mcmcan.txMsg.messageId = CAN_MESSAGE_ID1;
                    /* Send the CAN message with the previously defined TX message content */
                    while( IfxCan_Status_notSentBusy == IfxCan_Can_sendMessage(&g_mcmcan.canSrcNode, &g_mcmcan.txMsg, &g_mcmcan.txData[0]) )
                    {;}
                    splitter3++;
                    break;
                case 1 :
                    //-------------------------------------------------------------------------------
                    //                              CAN_MESSAGE_ID 2
                    //-------------------------------------------------------------------------------
                    IfxCan_Can_initMessage(&g_mcmcan.txMsg);
                    for (int didx= startidx; didx< startidx+2; didx++){ g_mcmcan.txData[didx-startidx] = TD->u32_data2[didx]; }
                    g_mcmcan.txMsg.messageId = CAN_MESSAGE_ID2;
                    while( IfxCan_Status_notSentBusy ==IfxCan_Can_sendMessage(&g_mcmcan.canSrcNode, &g_mcmcan.txMsg, &g_mcmcan.txData[0]) ) {;}
                    splitter3++;
                    break;
                case 2 :
                    //-------------------------------------------------------------------------------
                    //                              CAN_MESSAGE_ID 3
                    //-------------------------------------------------------------------------------
                    IfxCan_Can_initMessage(&g_mcmcan.txMsg);
                    for (int didx= startidx; didx< startidx+2; didx++){ g_mcmcan.txData[didx-startidx] = TD->u32_data3[didx]; }
                    g_mcmcan.txMsg.messageId = CAN_MESSAGE_ID3;
                    while( IfxCan_Status_notSentBusy ==IfxCan_Can_sendMessage(&g_mcmcan.canSrcNode, &g_mcmcan.txMsg, &g_mcmcan.txData[0]) ) {;}
                    splitter3++;
                    break;
                case 3 :
                    //-------------------------------------------------------------------------------
                    //                              CAN_MESSAGE_ID 4
                    //-------------------------------------------------------------------------------
                    IfxCan_Can_initMessage(&g_mcmcan.txMsg);
                    for (int didx= startidx; didx< startidx+2; didx++){ g_mcmcan.txData[didx-startidx] = TD->u32_data4[didx]; }
                    g_mcmcan.txMsg.messageId = CAN_MESSAGE_ID4;
                    while( IfxCan_Status_notSentBusy ==IfxCan_Can_sendMessage(&g_mcmcan.canSrcNode, &g_mcmcan.txMsg, &g_mcmcan.txData[0]) ) {;}
                    splitter3++;
                    break;
                case 4 :
                    //-------------------------------------------------------------------------------
                    //                              CAN_MESSAGE_ID 5
                    //-------------------------------------------------------------------------------
                    IfxCan_Can_initMessage(&g_mcmcan.txMsg);
                    for (int didx= startidx; didx< startidx+2; didx++){ g_mcmcan.txData[didx-startidx] = TD->u32_data5[didx]; }
                    g_mcmcan.txMsg.messageId = CAN_MESSAGE_ID5;
                    while( IfxCan_Status_notSentBusy ==IfxCan_Can_sendMessage(&g_mcmcan.canSrcNode, &g_mcmcan.txMsg, &g_mcmcan.txData[0]) ) {;}
                    splitter3++;
                    break;
                case 5 :
                    //-------------------------------------------------------------------------------
                    //                              CAN_MESSAGE_ID 6
                    //-------------------------------------------------------------------------------
                    IfxCan_Can_initMessage(&g_mcmcan.txMsg);
                    for (int didx= startidx; didx< startidx+2; didx++){ g_mcmcan.txData[didx-startidx] = TD->u32_data6[didx]; }
                    g_mcmcan.txMsg.messageId = CAN_MESSAGE_ID6;
                    while( IfxCan_Status_notSentBusy ==IfxCan_Can_sendMessage(&g_mcmcan.canSrcNode, &g_mcmcan.txMsg, &g_mcmcan.txData[0]) ) {;}
                    splitter3++;
                    break;
                case 6 :
                    //-------------------------------------------------------------------------------
                    //                              CAN_MESSAGE_ID 7
                    //-------------------------------------------------------------------------------
                    IfxCan_Can_initMessage(&g_mcmcan.txMsg);
                    for (int didx= startidx; didx< startidx+2; didx++){ g_mcmcan.txData[didx-startidx] = TD->u32_data7[didx]; }
                    g_mcmcan.txMsg.messageId = CAN_MESSAGE_ID7;
                    while( IfxCan_Status_notSentBusy ==IfxCan_Can_sendMessage(&g_mcmcan.canSrcNode, &g_mcmcan.txMsg, &g_mcmcan.txData[0]) ) {;}
                    splitter3++;
                    break;
                default :
                    splitter3 = 0;
                    startidx = startidx+ 2 ;
                    break;
            }
        }
        else{
            startidx = 0;
            //tx_trigger++;
            tx_trigger = 0;
        }
    }
}


/**
 *
 * @brief data_setup
 * @param TransData structure
 * @return null
 *
 */
int data_setup(struct TransData *TD){

    signalgener(); /* signal generator function will be displaced with real variables */
    data_picker();



    for (int didx= 0; didx< 90; didx++){ TD->data1[didx] = 1.*sinval[40*didx]; } // angular velocity [Wrpm]
    for (int didx= 0; didx< 90; didx++){ TD->data2[didx] = 2.*sinval[40*didx]; } // Torque [Nm]
    for (int didx= 0; didx< 90; didx++){ TD->data3[didx] = 3.*sinval[40*didx]; } // Vdsr   [V]
    for (int didx= 0; didx< 90; didx++){ TD->data4[didx] = 4.*sinval[40*didx]; } // Vqsr   [V]
    for (int didx= 0; didx< 90; didx++){ TD->data5[didx] = 100.*sinval[40*didx]; } // Idsr   [A]
    for (int didx= 0; didx< 90; didx++){ TD->data6[didx] = 1000.*sinval[40*didx]; } // Iqsr   [A]
    for (int didx= 0; didx< 90; didx++){ TD->data7[didx] = 10000.*sinval[40*didx]; } // Idc   [A]


    for (int didx= 0; didx< 90; didx++){ memcpy(&TD->u32_data1[didx], &TD->data1[didx], sizeof TD->data1[didx]); } // angular velocity [Wrpm]
    for (int didx= 0; didx< 90; didx++){ memcpy(&TD->u32_data2[didx], &TD->data2[didx], sizeof TD->data1[didx]); } // Torque [Nm]
    for (int didx= 0; didx< 90; didx++){ memcpy(&TD->u32_data3[didx], &TD->data3[didx], sizeof TD->data1[didx]); } // Vdsr   [V]
    for (int didx= 0; didx< 90; didx++){ memcpy(&TD->u32_data4[didx], &TD->data4[didx], sizeof TD->data1[didx]); } // Vqsr   [V]
    for (int didx= 0; didx< 90; didx++){ memcpy(&TD->u32_data5[didx], &TD->data5[didx], sizeof TD->data1[didx]); } // Idsr   [A]
    for (int didx= 0; didx< 90; didx++){ memcpy(&TD->u32_data6[didx], &TD->data6[didx], sizeof TD->data1[didx]); } // Iqsr   [A]
    for (int didx= 0; didx< 90; didx++){ memcpy(&TD->u32_data7[didx], &TD->data7[didx], sizeof TD->data1[didx]); } // Idc   [A]


    tx_trigger = 1;


    return tx_trigger;

}

void data_picker(void){


}
