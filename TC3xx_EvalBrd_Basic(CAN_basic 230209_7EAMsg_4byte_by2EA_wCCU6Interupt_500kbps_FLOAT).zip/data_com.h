/**    data_com.h .
*
*   @brief CAN-based data communication function
*   @author  Jaehoon Shim and Jung-Ik Ha
*   @date    2022.12 - 2023.11
*   @version 1.0.0
*   @section INFO
*   - This project is supported by LG Innotek coporation.
*
*/

#ifndef DATA_COM_H_
#define DATA_COM_H_ 1

/*********************************************************************************************************************/
/*-----------------------------------------------------Includes------------------------------------------------------*/
/*********************************************************************************************************************/
#include <stdio.h>
#include <string.h>
#include "Ifx_Types.h"
#include "IfxCan_Can.h"
#include "IfxCan.h"
#include "IfxCpu_Irq.h"
#include "IfxPort.h"                                        /* For GPIO Port Pin Control                            */
#include "utility.h"

/*********************************************************************************************************************/
/*------------------------------------------------------Macros-------------------------------------------------------*/
/*********************************************************************************************************************/
#define CAN_MESSAGE_ID1              (uint32)0x777           /* Message ID that will be used in arbitration phase    */
#define CAN_MESSAGE_ID2              (uint32)0x779           /* Message ID that will be used in arbitration phase    */
#define CAN_MESSAGE_ID3              (uint32)0x77B           /* Message ID that will be used in arbitration phase    */
#define CAN_MESSAGE_ID4              (uint32)0x77D           /* Message ID that will be used in arbitration phase    */
#define CAN_MESSAGE_ID5              (uint32)0x77F           /* Message ID that will be used in arbitration phase    */
#define CAN_MESSAGE_ID6              (uint32)0x781           /* Message ID that will be used in arbitration phase    */
#define CAN_MESSAGE_ID7              (uint32)0x783           /* Message ID that will be used in arbitration phase    */

#define PIN5                        5                       /* LED1 used in TX ISR is connected to this pin         */
#define PIN6                        6                       /* LED2 used in RX ISR is connected to this pin         */
#define INVALID_RX_DATA_VALUE       0xA5                    /* Used to invalidate RX message data content           */
#define INVALID_ID_VALUE            (uint32)0xFFFFFFFF      /* Used to invalidate RX message ID value               */
#define ISR_PRIORITY_CAN_TX         2                       /* Define the CAN TX interrupt priority                 */
#define ISR_PRIORITY_CAN_RX         1                       /* Define the CAN RX interrupt priority                 */
#define MAXIMUM_CAN_DATA_PAYLOAD    2                     /* Define maximum classical CAN payload in 4-byte words */


/*********************************************************************************************************************/
/*--------------------------------------------------Data Structures--------------------------------------------------*/
/*********************************************************************************************************************/
typedef struct
{
    IfxCan_Can_Config canConfig;                            /* CAN module configuration structure                   */
    IfxCan_Can canModule;                                   /* CAN module handle                                    */
    IfxCan_Can_Node canSrcNode;                             /* CAN source node handle data structure                */
    IfxCan_Can_Node canDstNode;                             /* CAN destination node handle data structure           */
    IfxCan_Can_NodeConfig canNodeConfig;                    /* CAN node configuration structure                     */
    IfxCan_Filter canFilter;                                /* CAN filter configuration structure                   */
    IfxCan_Message txMsg;                                   /* Transmitted CAN message structure                    */
    uint32 txData[MAXIMUM_CAN_DATA_PAYLOAD];                /* Transmitted CAN data array                           */
} McmcanType;
extern struct McmcanType;


struct TransData
{
    float data1[90];   // angular velocity [Wrpm]
    float data2[90];   // Torque [Nm]
    float data3[90];   // Vdsr   [V]
    float data4[90];   // Vqsr   [V]
    float data5[90];   // Idsr   [A]
    float data6[90];   // Iqsr   [A]
    float data7[90];   // IdcAvg [A]

    uint32 u32_data1[90];   // angular velocity [Wrpm]
    uint32 u32_data2[90];   // Torque [Nm]
    uint32 u32_data3[90];   // Vdsr   [V]
    uint32 u32_data4[90];   // Vqsr   [V]
    uint32 u32_data5[90];   // Idsr   [A]
    uint32 u32_data6[90];   // Iqsr   [A]
    uint32 u32_data7[90];   // IdcAvg [A]

    float d1ofs;        // angular velocity [Wrpm]
    float d1scale;      // angular velocity [Wrpm]
    float d2ofs;        // Torque [Nm]
    float d2scale;      // Torque [Nm]
    float d3ofs;        // Vdsr   [V]
    float d3scale;      // Vdsr   [V]
    float d4ofs;        // Vqsr   [V]
    float d4scale;      // Vqsr   [V]
    float d5ofs;        // Idsr   [A]
    float d5scale;      // Idsr   [A]
    float d6ofs;        // Iqsr   [A]
    float d6scale;      // Iqsr   [A]
    float d7ofs;        // IdcAvg [A]
    float d7scale;      // IdcAvg [A]

};
extern struct TransData TD;

/*********************************************************************************************************************/
/*--------------------------------------------------   Variables   --------------------------------------------------*/
/*********************************************************************************************************************/
extern int tx_trigger;
extern int splitter1;
extern int splitter2;
extern int splitter3;
extern int startidx;
/*********************************************************************************************************************/
/*-----------------------------------------------Function Prototypes-------------------------------------------------*/
/*********************************************************************************************************************/
void initdatacan(void);
void transmitCanMessage(struct TransData *TD);
int data_setup(struct TransData* TD);
void data_picker(void);

#endif /* DATA_COM_H_ */
